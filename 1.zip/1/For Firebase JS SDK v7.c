// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDK7aFVIAsvyADny2E3nRy_STh_H7NppEs",
  authDomain: "med-reminder-system.firebaseapp.com",
  projectId: "med-reminder-system",
  storageBucket: "med-reminder-system.firebasestorage.app",
  messagingSenderId: "320658705878",
  appId: "1:320658705878:web:fe93ec066d59c519c5e877",
  measurementId: "G-J42C1MF93Y"
};
